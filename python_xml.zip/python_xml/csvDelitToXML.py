__author__ = 'alexandre s. cavalcante'

from os import listdir
import xml.etree.cElementTree as ET
from collections import OrderedDict


path = './delits/fichiers_CSV/'

filesList = sorted(listdir(path))

racine = ET.Element('racine')

dictMois = OrderedDict(OrderedDict([('0', 'dec'), ('1', 'nov'), ('2', 'oct'), ('3', 'sept'), ('4', 'aout'), ('5', 'juil'), ('6', 'juin'), ('7', 'mai'), ('8', 'avril'), ('9', 'mars'), ('10', 'fev'), ('11', 'janv')]))

listAn = ['2014', '2013', '2012', '2011', '2010']

# lire fichiers dans
for item in filesList:
    file = open(path + item, 'r')

    #creer balise departement
    deptNum = file.name.split('.')[1].split('/')[3]
    dptBalise = ET.SubElement(racine, 'departement', codeInsee=deptNum)
    # departement.text = deptNum

    # lire les donnes de delits
    for line in file.readlines()[1:]:
        dataSeparated = line.strip().split(',')

        data2014 = dataSeparated[1:13]
        data2013 = dataSeparated[13:25]
        data2012 = dataSeparated[25:37]
        data2011 = dataSeparated[37:49]
        data2010 = dataSeparated[49:]

        # creer balise index de delit
        index = ET.SubElement(dptBalise, 'delit', code=dataSeparated[0])

        countMois = 1

        for an in listAn:

            #creer balise an
            anBalise = ET.SubElement(index, 'periode', an=an)

            for mois in dictMois.keys():
                # creer les balises pour le mois
                moisBalise = ET.SubElement(anBalise, dictMois[mois]).text = dataSeparated[countMois]
                print(dataSeparated[countMois] +' ' + dictMois[mois])
                countMois +=1


def indent(elem, level=0):
    i = "\n" + level*"  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level+1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i

tree = ET.ElementTree(racine)

indent(racine)


tree.write("delits.xml")




