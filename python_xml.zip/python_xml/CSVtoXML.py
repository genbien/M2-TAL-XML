__author__ = 'alexandre s. cavalcante'

import xml.etree.cElementTree as ET
import collections


# dictionnaire pour stocker les donnees
donnes = {}

######## Lecture des fichiers ###################################


# ---------------- LIRE FICHIER CARACTERISITIQUES -----------------------------#

# lire fichier caracteristique  # OBS --> CE FICHIER SEMBLE ETRE ENCONDE EN ISO-LATIN 1
fileCaracteristique = open('./2014/caracteristiques_2014.csv', 'r', encoding='iso-8859-1')

# lire a partir de la deuxieme ligne
fileCaracteristique.readline()[1:]

#lire fichier caracteristique
for line in fileCaracteristique:
    # enlever le retour a la ligne '\n'
    line = line.strip()

    # dans le fichiers caracteristique, les lignes finissent par une virgules, cette virgule doit etre enlevee
    if line.endswith(','):
        line = line[:-1]
    temp = str(line).split(',')
    donnes[temp.pop(0)] = temp


# ---------------- LIRE FICHIER LIEUX -----------------------------#

fileLieux = open('./2014/lieux_2014.csv', 'r')

# lire a partir de la deuxieme ligne
fileLieux.readline()[1:]

#lire fichier caracteristique
for line in fileLieux:
    temp = str(line).strip().split(',')
    donnes[temp.pop(0)] += temp

# ordonner diction donnes{}

donnes = collections.OrderedDict(sorted(donnes.items()))


'''ATTENTION - les fichiers vehicules et usargers possedent un plus d`un element par cle, leurs lecture doit etre faire
de maniere different'''

# ---------------- LIRE FICHIER VEHICULES -----------------------------#

'''
pour chaque cle du dictionnaire vehicules dous avons une liste, qui contient les liste des item repetes
Structure
dictVehicule { 'cle': [[1, 232, 23,2,2], [32, 2,32, 2, ,23,32]] }
la cle est numero accident
'''
dictVehicules = {}

fileLieux = open('./2014/vehicules_2014.csv', 'r')

# lire a partir de la deuxieme ligne
fileLieux.readline()[1:]

#lire fichier caracteristique
for line in fileLieux:
    temp = str(line).strip().split(',')
    # obtenir le numero d`accident
    numAcc = temp.pop(0)

    # verifier si la cle pour cet accident existe
    if numAcc in dictVehicules.keys():
        # rajouter les donnes pour un vehicule dans le dictVehicules
        dictVehicules[numAcc].append(temp)
    else:
        #creer la liste vide
        dictVehicules[numAcc] = []
        # rajouter les donnes pour un vehicule dans le dictVehicules
        dictVehicules[numAcc].append(temp)
#faire la consolidation des donnes des vehicules avec les autres donnes


dictVehicules = collections.OrderedDict(sorted(dictVehicules.items()))

for item in dictVehicules.keys():
    # pour la cle numAccident rajouter la liste qui contient les donnes de vehicules
    donnes[item].append(dictVehicules[item])


    # temp = donnes[item]
    # temp.append(dictVehicules[item])
    # donnes[item]= temp



# ---------------- LIRE FICHIER USAGERS -----------------------------#


dicUsager = {}

fileUsager = open('./2014/usagers_2014.csv', 'r')

# lire a partir de la deuxieme ligne
fileUsager.readline()[1:]

#lire fichier caracteristique
for line in fileUsager:
    temp = str(line).strip().split(',')
    # obtenir le numero d`accident
    numAcc = temp.pop(0)

    # verifier si la cle pour cet accident existe
    if numAcc in dicUsager.keys():
        # rajouter les donnes pour un vehicule dans le dicUsager
        dicUsager[numAcc].append(temp)
    else:
        dicUsager[numAcc] = []
        dicUsager[numAcc].append(temp)
#faire la consolidation des donnes des vehicules avec les autres donnes

dicUsager = collections.OrderedDict(sorted(dicUsager.items()))

for item in dicUsager.keys():
    # pour la cle numAccident rajouter la liste qui contient les donnes de vehicules
    donnes[item].append(dicUsager[item])



############## creation du fichier XML #####################


#---------------------- FICHIER CARACTERISTIQUES ---------------------------#

# dictionnaire code Lumiere
codeLumiere = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1': 'Plein jour', '2': 'Crépuscule ou aube', '3': 'Nuit sans éclairage public', '4': 'Nuit avec éclairage public non allumé', '5': 'Nuit avec éclairage public allumé'}

# dictionnaire code agglomeration
codeAgglomeration = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1': 'Hors aggloromération', '2': 'En agglomération'}

#dicitionnaire code Intersection
codeIntersection = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1': 'Hors intersection', '2':'Intersection en X', '3':'Intersection en T', '4': 'Intersection en Y', '5':'Intersection à plus de 4 branches', '6':'Giratoire', '7': 'Place', '8':'Passage à niveau', '9':'Autre intersection'}

#dictionnaire code Conditions atmosferiques
codeCondAtm = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'Normale', '2':'Pluie légère', '3':'Pluie forte', '4':'Neige - grêle', '5':'Brouillard - fumée', '6':'Vent fort - tempête', '7':'Temps éblouissant', '8':'Temps couvert', '9':'Autre'}

#dictionnaire code Colision
codeColision = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'Deux véhicules - frontale', '2':'Deux véhicules – par l’arrière', '3':'Deux véhicules – par le coté', '4':'Trois véhicules et plus – en chaîne', '5':'Trois véhicules et plus - collisions multiples', '6':'Autre collision', '7':'Sans collision'}

codeGPS = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','M':'Métropole','A':'Antilles (Martinique ou Guadeloupe)','G':'Guyane','R':'Réunion','Y':'Mayotte'}

#---------------------- FICHIER LIEUX ---------------------------#

# dictionnaire codeCategorie
codeCatergorie ={'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'Autoroute', '2':'Route Nationale', '3':'Route Départementale', '4':'Voie Communale', '5':'Hors réseau public', '6':'Parc de stationnement ouvert à la circulation publique', '9':'autre'}

# dicionnaire codeCirculation
codeCirculation = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'A sens unique', '2':'Bidirectionnelle', '3':'A chaussées séparées', '4':'Avec voies d’affectation variable'}

#dictionnaire VOSP
codeVOSP = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'Piste cyclable','2':'Banque cyclable','3':'Voie réservée'}

#dictionnaire Profil
codeProfil = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'Plat', '2':'Pente', '3':'Sommet de côte', '4':'Bas de côte'}

#dictionnaire Plan
codePlan = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'Partie rectiligne','2':'En courbe à gauche', '3':'En courbe à droite', '4':'En « S »'}

#dictionnaire surface
codeSurface = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'normale', '2':'mouillée', '3':'flaques', '4':'inondée', '5':'enneigée', '6':'boue', '7':'verglacée','8':'corps gras - huile', '9':'autre'}

#dictionnaire infrastructure
codeInfra = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'Souterrain - tunnel','2':'Pont - autopont', '3':'Bretelle d’échangeur ou de raccordement', '4':'Voie ferrée', '5':'Carrefour aménagé', '6':'Zone piétonne', '7':'Zone de péage'}

#dictionnaire situation
codeSituation = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'Sur chaussée', '2':'Sur bande d’arrêt d’urgence', '3':'Sur accotement', '4':'Sur trottoir', '5':'Sur piste cyclable'}

#--------------------- FICHIER VEHICULES- -------------------------------------#

codeSens ={'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'PK ou PR ou numéro d’adresse postale croissant', '2':'PK ou PR ou numéro d’adresse postale décroissant'}

codeCatv ={'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','01':'Bicyclette','02':'Cyclomoteur &lt; 50cm3','03':'Voiturette (Quadricycle à moteur carrossé) (anciennement "voiturette ou tricycle à moteur")','04':'Référence plus utilisée depuis 2006 (scooter immatriculé)','05':'Référence plus utilisée depuis 2006 (motocyclette)','06':'Référence plus utilisée depuis 2006 (side-car)'
,'07':'VL seul','08':'Catégorie plus utilisée (VL + caravane)','09':'Catégorie plus utilisée (VL + remorque)','10':'VU seul 1,5T &lt;= PTAC &lt;= 3,5T avec ou sans remorque (anciennement VU seul 1,5T &lt;= PTAC &lt;=3,5T)'
,'11':'Référence plus utilisée depuis 2006 (VU (10) + caravane)','12':'Référence plus utilisée depuis 2006 (VU (10) + remorque)','13':'PL seul 3,5T &lt;PTCA &lt;= 7,5T','14':'PL seul &gt; 7,5T','15':'PL &gt; 3,5T + remorque','16':'Tracteur routier seul','17':'Tracteur routier + semi-remorque', '18':'Référence plus utilisée depuis 2006 (transport en commun)','19':'Référence plus utilisée depuis 2006 (tramway)','20':'Engin spécial'
,'21':'Tracteur agricole','30':'Scooter &lt; 50 cm3','31':'Motocyclette &gt; 50 cm3 et &lt;= 125 cm3','32':'Scooter &gt; 50 cm3 et &lt;= 125 cm3'
,'33':'Motocyclette &gt; 125 cm3','34':'Scooter &gt; 125 cm3','35':'Quad léger &lt;= 50 cm3 (Quadricycle à moteur non carrossé)','36':'Quad lourd &gt; 50 cm3 (Quadricycle à moteur non carrossé)'
,'37':'Autobus','38':'Autocar','39':'Train','40':'Tramway','99':'Autre véhicule'}

codeObstacleFixe ={'':'CLE-NON-DEFINIE','00':'CLE-NON-DEFINIE','01':'Véhicule en stationnement','02':'Arbre','03':'Glissière métallique','04':'Glissière béton','05':'Autre glissière','06':'Bâtiment, mur, pile de pont','07':'Support de signalisation verticale ou poste d’appel d’urgence','08':'Poteau','09':'Mobilier urbain','10':'Parapet','11':'Ilot, refuge, borne haute','12':'Bordure de trottoir','13':'Fossé, talus, paroi rocheuse',
'14':'Autre obstacle fixe sur chaussée','15':'Autre obstacle fixe sur trottoir ou accotement','16':'Sortie de chaussée sans obstacle'}

# ATTENTION CE DICTIONNAIRE NE SUIT PAS UNE SEQUENCE DE NUMEROTATION!! IL MANQUE LE 3, 7 E 8
codeObstacleMobile = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'Piéton','2':'Véhicule', '4':'Véhicule sur rail','5':'Animal domestique','6':'Animal sauvage','9':'Autre'}

# dictionnaire code de choc
codeChoc = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'Avant','2':'Avant droit','3':'Avant gauche','4':'Arrière','5':'Arrière droit', '6':'Arrière gauche','7':'Côté droit', '8':'Côté gauche','9':'Chocs multiples (tonneaux)'}

codeManoeuvre = {'':'CLE-NON-DEFINIE','00':'CLE-NON-DEFINIE','01':'Manœuvre principale avant l’accident -Sans changement de direction','02':'Manœuvre principale avant l’accident -Même sens, même file','03':'Manœuvre principale avant l’accident -Entre 2 files','04':'Manœuvre principale avant l’accident -En marche arrière','05':'Manœuvre principale avant l’accident -A contresens','06':'Manœuvre principale avant l’accident -En franchissant le terre-plein central','07':'Manœuvre principale avant l’accident -Dans le couloir bus, dans le même sens','08':'Manœuvre principale avant l’accident -Dans le couloir bus, dans le sens inverse','09':'Manœuvre principale avant l’accident -En s’insérant','10':'Manœuvre principale avant l’accident -En faisant demi-tour sur la chaussée','11':'Changeant de file -A gauche','12':'Changeant de file -A droite','13':'Déporté -A gauche','14':'Déporté -A droite','15':'Tournant -A gauche','16':'Tournant -A droite','17':'Dépassant -A gauche','18':'Dépassant -A droite','19':'Divers -Traversant la chaussée','20':'Divers -Manœuvre de stationnement','21':'Divers -Manœuvre d’évitement','22':'Divers -Ouverture de porte','23':'Divers -Arrêté (hors stationnement)','24':'Divers -En stationnement (avec occupants)'}



#--------------------- FICHIER USAGERS- -------------------------------------#

codeCatUsager = {'1':' Conducteur','2':' Passager','3':' Piéton','4':' Piéton en roller ou en trottinette'}

codeGravite = {'1' :' Indemne','2' :' Tué','3' :' Blessé hospitalisé','4' :' Blessé léger'}

codeSexe = {'1':'Masculin', '2':'Fémin'}

codeTraje = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'Domicile – travail','2':'Domicile – école','3':'Courses – achats','4':'Utilisation professionnelle','5':'Promenade – loisirs','9':'Autre'}

codeSecurite1= {'1':'Ceinture','2':'Casque','3':'Dispositif enfants','4':'Equipement réfléchissant','9':'Autre'}

codeSecurite2= {'1':'Oui', '2':'Non', '3':'Non déterminable'}

codeLocPieton = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'Sur chaussée - A + 50 m du passage piéton','2':'Sur chaussée - A - 50 m du passage piéton','3':'Sur passage piéton - Sans signalisation lumineuse','4':'Sur passage piéton - Avec signalisation lumineuse','5':'Divers - Sur trottoir','6':'Divers - Sur accotement','7':'Divers - Sur refuge ou BAU','8':'Divers - Sur contre allée'}

codeActionPieton = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'Se déplaçant - Sens véhicule heurtant','2':'Se déplaçant - Sens inverse du véhicule','3':'Divers - Traversant','4':'Divers - Masqué','5':'Divers - Jouant – courant','6':'Divers - Avec animal','7':'Divers - Autre', '9':'CLE-NON-DEFINIE'}

codeEtatPieton = {'':'CLE-NON-DEFINIE','0':'CLE-NON-DEFINIE','1':'Seul', '2':'Accompagné', '3':'Seul'}

# creer balise racine
elementAccidents = ET.Element("accidents")

for key in donnes.keys():

    print(key)

    # creer balise accident
    elementAccident = ET.SubElement(elementAccidents, "accident", id=key)

    an = donnes[key][0]
    mois = donnes[key][1]
    jour = donnes[key][2]
    heure = donnes[key][3]

    # creer balise date
    elementDate = ET.SubElement(elementAccident, 'date').text = jour + '/' + mois + '/' + an
    elementHeure = ET.SubElement(elementAccident, 'heure').text = heure

    # creer balise lumiere en utilisant le code lumiere
    elementLumiere = ET.SubElement(elementAccident, 'lumiere').text = codeLumiere[donnes[key][4]]

    #creer balise agglomeration
    elementAgglomeration = ET.SubElement(elementAccident, 'agglomeration').text = codeAgglomeration[donnes[key][5]]

    #creer balise intersection
    elementIntersection = ET.SubElement(elementAccident, 'intersection').text = codeIntersection[donnes[key][6]]

    #creer balise conditionAtmosferique
    elementCondAtmosf = ET.SubElement(elementAccident, 'conditionsAtmosferiques').text = codeCondAtm[donnes[key][7]]

    #creer balise colision
    elementColision = ET.SubElement(elementAccident, 'colision').text = codeColision[donnes[key][8]]

    #creer balise localisation
    elementLocalisation = ET.SubElement(elementAccident, 'localisation')

    #creer balise commune
    elementCommune = ET.SubElement(elementLocalisation, 'commune').text = donnes[key][9]

    #creer balise adresse
    elementAdresse = ET.SubElement(elementLocalisation, 'adresse').text= donnes[key][10]

    #creer balise gps
    elementGPS = ET.SubElement(elementLocalisation, 'GPS').text = codeGPS[donnes[key][11]]

    #creer balise latitude
    elementLatitude = ET.SubElement(elementLocalisation, 'latitude').text = donnes[key][12]

    #creer balise longitude
    elementLongitude = ET.SubElement(elementLocalisation, 'longitude').text = donnes[key][13]

    #creer balise departement
    elementDepartement = ET.SubElement(elementLocalisation, 'departement').text = donnes[key][14]


# ------------------------------------------------- BALISE LIEUX ----------------------------------------------------------------------#

    #creer balise lieux
    elementLieux = ET.SubElement(elementAccident, 'lieux')

    #creer balise categorie
    elementCategorie = ET.SubElement(elementLieux, 'categorie').text = codeCatergorie[donnes[key][15]]

    #creer balise voie
    elementVoie = ET.SubElement(elementLieux, 'voie').text = donnes[key][16]

    # creer balise V1
    elementV1 = ET.SubElement(elementLieux, 'v1').text = donnes[key][17]

    #creer balise V2
    elmentV2 = ET.SubElement(elementLieux, 'v2').text = donnes[key][18]

    #creer balise circulation
    elementCirculation = ET.SubElement(elementLieux, 'circulation').text = codeCirculation[donnes[key][19]]

    #creer balise NbVoie
    elementNbVoie = ET.SubElement(elementLieux, 'nbVoie').text = donnes[key][20]

    #creer balise pr
    elementPr = ET.SubElement(elementLieux, 'pr').text = donnes[key][21]

    #creer balise pr1
    elementPr1 = ET.SubElement(elementLieux, 'pr1').text = donnes[key][22]

    #creer balise vosp
    elementVOSP = ET.SubElement(elementLieux, 'vosp').text = codeVOSP[donnes[key][23]]

    #creer balise profil
    elementProfil = ET.SubElement(elementLieux, 'profil').text = codeProfil[donnes[key][24]]

    #creer balise plan
    elementPlan = ET.SubElement(elementLieux, 'plan').text = codePlan[donnes[key][25]]

    #creer balise Lartpc
    elementLartpc = ET.SubElement(elementLieux, 'lartpc').text = donnes[key][26]

    #creer balise Larrout
    elementLarrout = ET.SubElement(elementLieux, 'larrout').text = donnes[key][27]

    # creer balise surface
    elementSurface = ET.SubElement(elementLieux, 'surface').text = codeSurface[donnes[key][28]]

    #creer balise infra
    elementInfra = ET.SubElement(elementLieux, 'infra').text = codeInfra[donnes[key][29]]

    #creer balise  situation
    elementSituation = ET.SubElement(elementLieux, 'situation').text = codeSituation[donnes[key][30]]

    #creer balise env1
    elementEnv1 = ET.SubElement(elementLieux, 'env1').text = donnes[key][31]


    # ---------------------- BALISE VEHICULE -------------------------------------------------#

    #creer balise vehicules
    elementVehicules = ET.SubElement(elementAccident, 'vehicules')

    for item in donnes[key][32]:

        #creer balise vehicule
        elementVehicule = ET.SubElement(elementVehicules, 'vehicule')

        #creer balise sens
        elementSens = ET.SubElement(elementVehicule, 'sens').text = codeSens[item[0]]

        # creer balise
        elementCatv = ET.SubElement(elementVehicule, 'catv').text = codeCatv[item[1]]

        #creer balise nombreOccupants
        elementNombreOccupants = ET.SubElement(elementVehicule, 'nombreOccupants').text = item[2]

        #creer balise obstacleFixe
        elementObstacleFixe = ET.SubElement(elementVehicule, 'obstacleFixe').text = codeObstacleFixe[item[3]]

        #creer balise obstacleMobile
        elementObstacleMobile = ET.SubElement(elementVehicule, 'obstacleMobile').text = codeObstacleMobile[item[4]]

        #creer balise choc
        elementChoc = ET.SubElement(elementVehicule, 'choc').text = codeChoc[item[5]]

        #creer balise manouvre
        elementManoeuvre = ET.SubElement(elementVehicule, 'manoeuvre').text = codeManoeuvre[item[6]]

        #creer balise numVehicule
        elementNumVehicule = ET.SubElement(elementVehicule, 'numVehicule').text = item[7]


    # ---------------------- BALISE USAGERs -------------------------------------------------#


    #creer balise usagers
    elementUsagers = ET.SubElement(elementAccident, 'usagers')

    for item in donnes[key][33]:

        elementUsager = ET.SubElement(elementUsagers, 'usager')

        elementPlace = ET.SubElement(elementUsager, 'place').text = item[0]

        elementCatUsager = ET.SubElement(elementUsager, 'catUsager').text = codeCatUsager[item[1]]

        elementGravite = ET.SubElement(elementUsager, 'gravite').text = codeGravite[item[2]]

        elementSexe = ET.SubElement(elementUsager, 'sexe').text = codeSexe[item[3]]

        elementTrajet = ET.SubElement(elementUsager, 'trajet').text = codeTraje[item[4]]

        # traiter les options du code securite

        elementSecurite = ET.SubElement(elementUsager, 'securite')

        if len(item[5]) == 2:
            elementExistence = ET.SubElement(elementSecurite, 'existence').text = codeSecurite1[item[5][0]]
            elementUtilisation = ET.SubElement(elementSecurite, 'utilistion').text = codeSecurite2[item[5][1]]

        # todo analyser ce probleme - quoi faire s`il y a qu`un code. Par l`instant, on utilise pour elementUtilisation. A DECIDER!
        if len(item[5]) == 1:
            elementUtilisation = ET.SubElement(elementSecurite, 'utilistion').text = codeSecurite2[item[5][0]]

        elementPieton = ET.SubElement(elementUsager, 'pieton')

        elementLocPieton = ET.SubElement(elementPieton, 'locPieton').text = codeLocPieton[item[6]]

        elementActionPieton = ET.SubElement(elementPieton, 'actionPieton').text = codeActionPieton[item[7]]

        elementEtatPieton = ET.SubElement(elementPieton, 'etatPieton').text = codeEtatPieton[item[8]]

        elementAnNaissanceUsager = ET.SubElement(elementUsager, 'anNaissanceUsager').text = item[9]

print('fin lecture des fichiers')

def indent(elem, level=0):
    i = "\n" + level*"  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level+1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i

tree = ET.ElementTree(elementAccidents)

indent(elementAccidents)


tree.write("filename_2014.xml")